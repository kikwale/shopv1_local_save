<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CreditSalesController extends Controller
{
    //
}
